{$MODE OBJFPC}
{$MODESWITCH NESTEDCOMMENTS+}

{
=======================================================================
 This program is intended for use in testing
 with a random testing program like Practrand
=======================================================================
}

program test_prng_5;
uses	sysutils
,		strutils
,		strings
,		Unit_PRNG
;

const
C_MAX		= 1000000000000;

var
i,R,E,N		:int_type;
R_MAX		:int_type;
N_BITS		:int_type;
COUNT		:int_type;
COUNT_STR	:string;
B			:int8u;
date_time	:int_type = 0;
bin_or_text	:string;

PRNG1	:T_PRNG_record;
PRNG2	:T_PRNG_record_RD;

(*------------------------------*)
begin
COUNT:= strtoint64def(ParamStr(1),0);

if	(ParamCount = 0)
then
	begin
	writeln('Usage:');
    writeln('test_prng_5 <num-of bytes> <BIN|TEXT> <bits-per-rand>');
    exit;
	end;
i:= 1;
while(i <= ParamCount) do
	begin
	case i of
		1: R_MAX:= strtoint64def(ParamStr(i),0);
		2: bin_or_text:= ParamStr(i);
		3: N_BITS:= strtoint64def(ParamStr(i),0);
	end;
	inc(i);
	end;

if	(R_MAX = 0) or (N_BITS = 0) then exit;

PRNG_initialise(PRNG1);
// PRNG_initialise(PRNG1,ENABLE_INFINITE_PERIOD);

PRNG_randomise(PRNG1,E);	// the ramdonise function re-seeds the PRNG with random parameters
if	(E <> PRNG_ERROR_OK) then
	begin
	writeln('PRNG ERROR ',E);
	exit;
	end;

I:= 0;
repeat
	if	(bin_or_text = 'BIN') then
	    case N_BITS of
		    8:
			    begin
			    R:= calc_8bit_rand(PRNG1);
		        b:= (R and 255);
			    write(chr(b));
				Inc(I);
			    end;
		    16:
			    begin
			    R:= calc_16bit_rand(PRNG1);
			    for N:= 1 to 2 do
				    begin
			        b:= (R and 255); R:= (R >> 8);
			        write(chr(b));
					Inc(I);
				    end;
			    end;
		    24:
			    begin
			    R:= calc_24bit_rand(PRNG1);
			    for N:= 1 to 3 do
				    begin
			        b:= (R and 255); R:= (R >> 8);
			        write(chr(b));
					Inc(I);
				    end;
			    end;
		    32:
			    begin
			    R:= calc_32bit_rand(PRNG1);
			    for N:= 1 to 4 do
				    begin
			        b:= (R and 255); R:= (R >> 8);
			        write(chr(b));
					Inc(I);
				    end;
			    end;
		    64:
			    begin
			    R:= calc_64bit_rand(PRNG1);
			    for N:= 1 to 8 do
				    begin
			        b:= (R and 255); R:= (R >> 8);
			        write(chr(b));
					Inc(I);
				    end;
			    end;
	    else begin writeln('Incorrect number of bits specified'); exit; end;
	    end
	else if	(bin_or_text = 'TEXT') then
		begin
	    case N_BITS of
		    8:	begin R:= calc_8bit_rand(PRNG1); Inc(I); end;
		    16: begin R:= calc_16bit_rand(PRNG1); I:=I+2; end;
		    24: begin R:= calc_24bit_rand(PRNG1); I:=I+3; end;
		    32: begin R:= calc_32bit_rand(PRNG1); I:=I+4; end;
		    64: begin R:= calc_64bit_rand(PRNG1); I:=I+8; end;
	    else begin writeln('Incorrect number of bits specified'); exit; end;
	    end;
		writeln(R);
		end
	else begin writeln('bin_or_text must = "TEXT" or "BIN"'); exit; end;
until (I >= R_MAX);

end.

