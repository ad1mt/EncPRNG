{$MODE OBJFPC}
{$MODESWITCH NESTEDCOMMENTS+}

unit Encrypt_P;

(*------------------------------*)
{
v4.01	1.	Use new EncPRNG unit.
v4.02	2.	Replace error message of '0' with 'Unknown error'.
v4.03	1.	Validate password
v6.01	1.	Compress data before encrypting; decompress after decrypting.
v6.02	1.	Works with Encrypt_CMD
v6.03	1.	Compression
v6.04	1.	Changes for Encrypt_Win
}

INTERFACE

uses	sysutils
,		classes
,		ZStream
,		StrUtils
,		Unit_PRNG
,		Unit_Multi_UBool
;

{$IFDEF CPU64}
	{$define 64bit}
{$ELSE}
  	{$define 32bit}
{$ENDIF}

const
VERSION				= '6.05';
WHO_I_AM			= 'Marks Encrypt';
WHO_I_AM_VERSION	= WHO_I_AM + ' v' + VERSION;
BUFFER_SIZE			= 102400;

type
T_ERROR_CODE		= (T_ERR_OK, T_ERR_PASSWORD, T_ERR_FILE, T_ERR_PRNG, T_ERR_COMPRESS, T_ERR_WARN, T_ERR_INTERNAL);
T_BYTE_ARRAY		= array[1..BUFFER_SIZE] of byte;
T_FILE_CRYPT_TYPE	= (T_NULL_CRYPT, T_ZEN_FILE, T_ENC_FILE);

var
PASSWORD_STR		:ansistring;
OUTPUT_FILE_NAME	:ansistring;
INPUT_FILE_NAME		:ansistring;
SELECTED_FILE_NAME	:ansistring;
PLAIN_FILE_NAME		:ansistring;
CRYPT_FILE_NAME		:ansistring;
BASE_FILE_NAME		:ansistring;
COMPRESS_SETTING	:T_Multi_UBool;

FILE_CRYPT_TYPE		:T_FILE_CRYPT_TYPE;

FILE_BYTES		:T_BYTE_ARRAY;

ERROR_CODE		:T_ERROR_CODE;
ERROR_MESS		:ansistring;

Compressor		:TCompressionStream;
Decompressor	:TDecompressionStream;
CompressedData	:TMemoryStream;

procedure open_input_file;
procedure open_output_file;
procedure close_input_file;
procedure close_output_file;
procedure encrypt_file;
procedure decrypt_file;
procedure Compress_Encrypt;
procedure Compress_Decrypt;
procedure decrypt_filenames;
procedure encrypt_filenames;
function password_valid:ansistring;
procedure check_filenames;

IMPLEMENTATION

var
OUTPUT_FILE,
INPUT_FILE		:FILE;
PRNG1			:T_PRNG_record;
PRNG_ERROR		:int64u;

(*------------------------------*)
function password_valid:ansistring;
var	R:int32;
begin
Result:= '';
R:= validate_password(PASSWORD_STR);
if	(R = PRNG_ERROR_PASSWORD_LEN) then
	begin
	Result:= 'Password length must be > 0 and < 78';
	PASSWORD_STR:= ''
    end;
if	(R = PRNG_ERROR_PASSWORD_CHARS) then
	begin
	Result:= 'Password length must be > 0 and < 78';
	PASSWORD_STR:= ''
    end;
end;


(*------------------------------*)
procedure check_filenames;
var
L			:int32;
T_FILE_NAME	:ansistring;
begin
CRYPT_FILE_NAME:= '';
FILE_CRYPT_TYPE:= T_NULL_CRYPT;
L:= length(SELECTED_FILE_NAME);

if	(UpCase(AnsiRightStr(SELECTED_FILE_NAME, 4)) = '.ZEN')
then
	begin
	CRYPT_FILE_NAME:= SELECTED_FILE_NAME;
	FILE_CRYPT_TYPE:= T_ZEN_FILE;
	T_FILE_NAME:= AnsiLeftStr(SELECTED_FILE_NAME, (L - 4));
	PLAIN_FILE_NAME:=	AnsiLeftStr(T_FILE_NAME, (L - 8))
					+	'.'
					+	AnsiRightStr(T_FILE_NAME, 3);
	end
else if	(UpCase(AnsiRightStr(SELECTED_FILE_NAME,4)) = '.ENC')
then
	begin
	CRYPT_FILE_NAME:= SELECTED_FILE_NAME;
	FILE_CRYPT_TYPE:= T_ENC_FILE;
	T_FILE_NAME:= AnsiLeftStr(SELECTED_FILE_NAME, (L - 4));
	PLAIN_FILE_NAME:=	AnsiLeftStr(T_FILE_NAME, (L - 8))
					+	'.'
					+	AnsiRightStr(T_FILE_NAME, 3);
	end
else
	begin
	PLAIN_FILE_NAME:= SELECTED_FILE_NAME;

	if	COMPRESS_SETTING
	and	fileExists(PLAIN_FILE_NAME+'.ZEN')
	then
		begin
		CRYPT_FILE_NAME:= PLAIN_FILE_NAME+'.ZEN';
		FILE_CRYPT_TYPE:= T_ZEN_FILE;
		end;

	if	(not COMPRESS_SETTING)
	and	fileExists(PLAIN_FILE_NAME+'.ENC') then
		begin
		CRYPT_FILE_NAME:= PLAIN_FILE_NAME+'.ENC';
		FILE_CRYPT_TYPE:= T_ENC_FILE;
		end;

	if	(FILE_CRYPT_TYPE = T_NULL_CRYPT)
	and	COMPRESS_SETTING
	then
		begin
		if	fileExists(PLAIN_FILE_NAME+'.ENC') then
			begin
			CRYPT_FILE_NAME:= PLAIN_FILE_NAME+'.ENC';
			FILE_CRYPT_TYPE:= T_ENC_FILE;
			end;
		end;

	if	(FILE_CRYPT_TYPE = T_NULL_CRYPT)
	and	(not COMPRESS_SETTING)
	then
		begin
		if	fileExists(PLAIN_FILE_NAME+'.ZEN') then
			begin
			CRYPT_FILE_NAME:= PLAIN_FILE_NAME+'.ZEN';
			FILE_CRYPT_TYPE:= T_ZEN_FILE;
			end;
		end;
	end;

BASE_FILE_NAME:= ExtractFileName(PLAIN_FILE_NAME);
end;

(*------------------------------*)
procedure encrypt_filenames;
begin
ERROR_MESS:= '';
ERROR_CODE:= T_ERR_OK;
INPUT_FILE_NAME:= '';

check_filenames;

if not fileExists(PLAIN_FILE_NAME) then
	begin
	if	(FILE_CRYPT_TYPE <> T_NULL_CRYPT) then
		begin
		ERROR_MESS:= 'File is already encrypted';
		ERROR_CODE:= T_ERR_FILE;
		end
	else
		begin
		ERROR_MESS:= 'File not found';
		ERROR_CODE:= T_ERR_FILE;
		end;
	exit;
	end;

INPUT_FILE_NAME:= PLAIN_FILE_NAME;

if	COMPRESS_SETTING then
	CRYPT_FILE_NAME:= PLAIN_FILE_NAME+'.ZEN'
else
	CRYPT_FILE_NAME:= PLAIN_FILE_NAME+'.ENC';

OUTPUT_FILE_NAME:= CRYPT_FILE_NAME;
end;

(*---------------v2-------------*)
procedure decrypt_filenames;
begin
ERROR_MESS:= '';
ERROR_CODE:= T_ERR_OK;
INPUT_FILE_NAME:= '';

check_filenames;

if (FILE_CRYPT_TYPE = T_NULL_CRYPT) then
	begin
	ERROR_MESS:= 'Encrypted file not found';
	ERROR_CODE:= T_ERR_FILE;
	exit
	end;

INPUT_FILE_NAME:= CRYPT_FILE_NAME;
OUTPUT_FILE_NAME:= PLAIN_FILE_NAME;
end;

(*------------------------------*)
procedure open_input_file;
begin
if not FileExists(INPUT_FILE_NAME) then
	begin
	ERROR_MESS:= 'Input file not found';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end;
assignfile(INPUT_FILE,INPUT_FILE_NAME);
{$I-}
reset(INPUT_FILE,1);
{$I+}
if (IoResult <> 0) then
	begin
	ERROR_MESS:= inttostr(IOResult);
	if (ERROR_MESS = '0') then ERROR_MESS:= 'Input file unknown error';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end
else ERROR_CODE:= T_ERR_OK;
end;

(*------------------------------*)
procedure open_output_file;
begin
assignfile(OUTPUT_FILE,OUTPUT_FILE_NAME);
{$I-}
rewrite(OUTPUT_FILE,1);
{$I+}
if (IoResult <> 0) then
	begin
	ERROR_MESS:= inttostr(IOResult);
	if (ERROR_MESS = '0') then ERROR_MESS:= 'Output file unknown error';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end
else ERROR_CODE:= T_ERR_OK;
end;

(*------------------------------*)
procedure close_output_file;
begin
{$I-}
close(OUTPUT_FILE);
{$I+}
if (IoResult <> 0) then
	begin
	ERROR_MESS:= inttostr(IOResult);
	if (ERROR_MESS = '0') then ERROR_MESS:= 'Output file unknown error';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end
else ERROR_CODE:= T_ERR_OK;
end;

(*------------------------------*)
procedure close_input_file;
begin
{$I-}
close(INPUT_FILE);
{$I+}
if (IoResult <> 0) then
	begin
	ERROR_MESS:= inttostr(IOResult);
	if (ERROR_MESS = '0') then ERROR_MESS:= 'Input file unknown error';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end
else ERROR_CODE:= T_ERR_OK;
end;

(*------------------------------*)
procedure Compress_Encrypt;
var
	BLOCK_INDEX		:int32;
	NUM_WRITTEN		:int32;
	NUM_READ		:int32;

	INPUT_BYTE,
	OUTPUT_BYTE		:int8u;

	DATE_TIME		:int64u;

begin
PRNG_initialise(PRNG1);

// randomise using date_time and password

DATE_TIME:= 0;
PRNG_randomise_from_password(PRNG1,PASSWORD_STR,DATE_TIME,PRNG_ERROR);
if not PRNG1.INITIALISED then
	begin
	if (PRNG_ERROR = PRNG_ERROR_SEED) then
		ERROR_MESS:= 'Failed to initialise PRNG - unable to generate enough randomness'

	else if (PRNG_ERROR = PRNG_ERROR_PASSWORD_CHARS) then
		ERROR_MESS:= 'Failed to initialise PRNG - password must not contain international characters'

	else if (PRNG_ERROR = PRNG_ERROR_PASSWORD_LEN) then
		ERROR_MESS:= 'Failed to initialise PRNG - password length must be > zero and < 78'

	else ERROR_MESS:= 'Failed to initialise PRNG - unknown error';

	ERROR_CODE:= T_ERR_PRNG;
	exit;
	end;

// write date_time to output file

NUM_READ:= 0;
while (NUM_READ < 8) do
	begin
    OUTPUT_BYTE:= int8u(DATE_TIME and INT8U_MAXINT);
	{$I-}
	blockwrite(OUTPUT_FILE,OUTPUT_BYTE,1,NUM_WRITTEN);
	{$I+}
	if	(NUM_WRITTEN < 1)
	or	(IOResult > 0) then
		begin
		ERROR_MESS:= inttostr(IOResult);
		if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
		ERROR_CODE:= T_ERR_FILE;
		exit;
		end;
    DATE_TIME:= (DATE_TIME >> 8);
	Inc(NUM_READ);
	end;

{ Create Streams }
CompressedData := TMemoryStream.Create();
Compressor     := TCompressionStream.Create(clmax, CompressedData);

// compress data & write to memory stream

repeat
	{$I-}
	blockread(INPUT_FILE, FILE_BYTES, BUFFER_SIZE, NUM_READ);
	{$I+}
	if	(IOResult > 0) then
		begin
		ERROR_CODE:= T_ERR_FILE;
		ERROR_MESS:= 'Input file read error ' + inttostr(IOResult);
		exit;
		end;

	if	(NUM_READ > 0) then
		begin
		Compressor.writebuffer(FILE_BYTES, NUM_READ);
		end;
until (NUM_READ = 0);

Compressor.Destroy;

// encrypt data & write to output file

CompressedData.Position := 0;
repeat
	NUM_READ:= CompressedData.read(FILE_BYTES, BUFFER_SIZE);
	if	(NUM_READ > 0) then
		begin
        BLOCK_INDEX:= 0;
		while (BLOCK_INDEX < NUM_READ) do
			begin
			Inc(BLOCK_INDEX);
			INPUT_BYTE:= FILE_BYTES[BLOCK_INDEX];
			OUTPUT_BYTE:= (INPUT_BYTE xor calc_8bit_rand(PRNG1));
	        FILE_BYTES[BLOCK_INDEX]:= OUTPUT_BYTE;
			end;

		{$I-}
		blockwrite(OUTPUT_FILE, FILE_BYTES, NUM_READ, NUM_WRITTEN);
		{$I+}
		if	(IOResult > 0) then
			begin
			ERROR_MESS:= inttostr(IOResult);
			if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
			ERROR_CODE:= T_ERR_FILE;
			exit;
			end;
		end;
until (NUM_READ < BUFFER_SIZE);

CompressedData.Destroy;

ERROR_CODE:= T_ERR_OK;
ERROR_MESS:= '';
end;


(*------------------------------*)
procedure Compress_Decrypt;
var
	BLOCK_INDEX		:int32;
	NUM_WRITTEN		:int32;
	NUM_READ		:int32;
	dt_byte			:int64u;
	INPUT_BYTE,
	OUTPUT_BYTE		:int8u;
	DATE_TIME		:int64u;
begin
DATE_TIME:= 0;

PRNG_initialise(PRNG1);

// read date_time from encrypted file
DATE_TIME:= 0;
NUM_WRITTEN:= 0;
while (NUM_WRITTEN < 8) do
	begin
	{$I-}
	blockread(INPUT_FILE,INPUT_BYTE,1,NUM_READ);
	{$I+}
	if	(NUM_READ < 1)
	or	(IOResult > 0) then
		begin
		ERROR_MESS:= inttostr(IOResult);
		if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
		ERROR_CODE:= T_ERR_FILE;
		exit;
		end;
    dt_byte:= int8u(INPUT_BYTE);
	dt_byte:= (dt_byte << (NUM_WRITTEN * 8));
    DATE_TIME:= (DATE_TIME + dt_byte);
	Inc(NUM_WRITTEN);
	end;

// randomise using date_time from encrypted file and password
// this initialises the PRNG with same seeds as encryption stage

PRNG_randomise_from_password(PRNG1,PASSWORD_STR,DATE_TIME,PRNG_ERROR);
if not PRNG1.INITIALISED then
	begin
	if (PRNG_ERROR = PRNG_ERROR_SEED) then
		ERROR_MESS:= 'Failed to initialise PRNG - unable to generate enough randomness'

	else if (PRNG_ERROR = PRNG_ERROR_PASSWORD_CHARS) then
		ERROR_MESS:= 'Failed to initialise PRNG - password must not contain international characters'

	else if (PRNG_ERROR = PRNG_ERROR_PASSWORD_LEN) then
		ERROR_MESS:= 'Failed to initialise PRNG - password length must be > zero and < 78'

	else ERROR_MESS:= 'Failed to initialise PRNG - unknown error';

	ERROR_CODE:= T_ERR_PRNG;
	exit;
	end;

// read data, decrypt & write to decompression stream

CompressedData := TMemoryStream.Create();
repeat
	{$I-}
	blockread(INPUT_FILE, FILE_BYTES, BUFFER_SIZE, NUM_READ);
	{$I+}
	if	(IOResult > 0) then
		begin
		ERROR_CODE:= T_ERR_FILE;
		ERROR_MESS:= 'Input file read error ' + inttostr(IOResult);
		exit;
		end;
	if	(NUM_READ > 0) then
		begin
        BLOCK_INDEX:= 0;
		while (BLOCK_INDEX < NUM_READ) do
			begin
			Inc(BLOCK_INDEX);
			INPUT_BYTE:= FILE_BYTES[BLOCK_INDEX];
			OUTPUT_BYTE:= (INPUT_BYTE xor calc_8bit_rand(PRNG1));
	        FILE_BYTES[BLOCK_INDEX]:= OUTPUT_BYTE;
			end;

		NUM_WRITTEN:= CompressedData.write(FILE_BYTES, NUM_READ);
		if	(NUM_WRITTEN < NUM_READ) then
			begin
			ERROR_CODE:= T_ERR_INTERNAL;
			ERROR_MESS:= 'Internal error: stream write';
			exit;
			end;
		end;
until (NUM_READ < BUFFER_SIZE);

// decompress data & write to output file

CompressedData.Position := 0;
Decompressor:= TDecompressionStream.Create(CompressedData);
repeat
	try	NUM_READ:= Decompressor.read(FILE_BYTES, BUFFER_SIZE);
	except
		begin
		ERROR_CODE:= T_ERR_COMPRESS;
		ERROR_MESS:= 'Decompress error: corrupt data or invalid password';
		exit;
		end;
	end;
	if	(NUM_READ > 0) then
		begin
		{$I-}
		blockwrite(OUTPUT_FILE, FILE_BYTES, NUM_READ, NUM_WRITTEN);
		{$I+}
		if	(IOResult > 0)
		or	(NUM_WRITTEN < NUM_READ)
		then
			begin
			ERROR_MESS:= inttostr(IOResult);
			if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
			ERROR_CODE:= T_ERR_FILE;
			exit;
			end;
		end;
until (NUM_READ < BUFFER_SIZE);

Decompressor.Destroy;
CompressedData.Destroy;

ERROR_CODE:= T_ERR_OK;
ERROR_MESS:= '';
end;


(*------------------------------*)
procedure Encrypt_File;
var
	INPUT_BYTE		:int8u;
	OUTPUT_BYTE		:int8u;

	BLOCK_INDEX		:int32;
	NUM_WRITTEN		:int32;
	NUM_READ		:int32;

	DATE_TIME		:int64u;
begin
PRNG_initialise(PRNG1);

// randomise using date_time and password

DATE_TIME:= 0;
PRNG_randomise_from_password(PRNG1,PASSWORD_STR,DATE_TIME,PRNG_ERROR);
if not PRNG1.INITIALISED then
	begin
	if (PRNG_ERROR = PRNG_ERROR_SEED) then
		ERROR_MESS:= 'Failed to initialise PRNG - unable to generate enough randomness'

	else if (PRNG_ERROR = PRNG_ERROR_PASSWORD_CHARS) then
		ERROR_MESS:= 'Failed to initialise PRNG - password must not contain international characters'

	else if (PRNG_ERROR = PRNG_ERROR_PASSWORD_LEN) then
		ERROR_MESS:= 'Failed to initialise PRNG - password length must be > zero and < 78'

	else ERROR_MESS:= 'Failed to initialise PRNG - unknown error';

	ERROR_CODE:= T_ERR_PRNG;
	exit;
	end;

// write date_time to output file

NUM_READ:= 0;
while (NUM_READ < 8) do
	begin
    OUTPUT_BYTE:= int8u(DATE_TIME and INT8U_MAXINT);
	{$I-}
	blockwrite(OUTPUT_FILE,OUTPUT_BYTE,1,NUM_WRITTEN);
	{$I+}
	if	(NUM_WRITTEN < 1)
	or	(IOResult > 0) then
		begin
		ERROR_MESS:= inttostr(IOResult);
		if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
		ERROR_CODE:= T_ERR_FILE;
		exit;
		end;
    DATE_TIME:= (DATE_TIME >> 8);
	Inc(NUM_READ);
	end;

// write data to output file

num_read:= -1;
repeat
	{$I-}
	blockread(INPUT_FILE,FILE_BYTES,BUFFER_SIZE,num_read);
	{$I+}
	if	(IOResult > 0) then
		begin
		ERROR_CODE:= T_ERR_FILE;
		ERROR_MESS:= 'Input file read error ' + inttostr(IOResult);
		exit;
		end;
	if	(num_read > 0) then
		begin
        BLOCK_INDEX:= 0;
		while (BLOCK_INDEX < num_read) do
			begin
			Inc(BLOCK_INDEX);
			INPUT_BYTE:= FILE_BYTES[BLOCK_INDEX];
			OUTPUT_BYTE:= (INPUT_BYTE xor calc_8bit_rand(PRNG1));
	        FILE_BYTES[BLOCK_INDEX]:= OUTPUT_BYTE;
			end;

		{$I-}
		blockwrite(OUTPUT_FILE,FILE_BYTES,num_read,num_written);
		{$I+}
		if	(num_written < num_read)
		or	(IOResult > 0) then
			begin
			ERROR_CODE:= T_ERR_FILE;
			ERROR_MESS:= 'Output file write error ' + inttostr(IOResult);
			exit;
			end;
		end;
until	(num_read < BUFFER_SIZE);
end;


(*------------------------------*)
procedure Decrypt_File;
var
	INPUT_BYTE		:int8u;
	OUTPUT_BYTE		:int8u;

	BLOCK_INDEX		:int32;
	NUM_WRITTEN		:int32;
	NUM_READ		:int32;

	DATE_TIME		:int64u;
	dt_byte			:int64u;

begin
DATE_TIME:= 0;

PRNG_initialise(PRNG1);

// read date_time from encrypted file
DATE_TIME:= 0;
NUM_WRITTEN:= 0;
while (NUM_WRITTEN < 8) do
	begin
	{$I-}
	blockread(INPUT_FILE,INPUT_BYTE,1,NUM_READ);
	{$I+}
	if	(NUM_READ < 1)
	or	(IOResult > 0) then
		begin
		ERROR_MESS:= inttostr(IOResult);
		if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
		ERROR_CODE:= T_ERR_FILE;
		exit;
		end;
    dt_byte:= int8u(INPUT_BYTE);
	dt_byte:= (dt_byte << (NUM_WRITTEN * 8));
    DATE_TIME:= (DATE_TIME + dt_byte);
	Inc(NUM_WRITTEN);
	end;

// randomise using date_time from encrypted file and password
// this initialises the PRNG with same seeds as encryption stage

PRNG_randomise_from_password(PRNG1,PASSWORD_STR,DATE_TIME,PRNG_ERROR);
if not PRNG1.INITIALISED then
	begin
	if (PRNG_ERROR = PRNG_ERROR_SEED) then
		ERROR_MESS:= 'Failed to initialise PRNG - unable to generate enough randomness'

	else if (PRNG_ERROR = PRNG_ERROR_PASSWORD_CHARS) then
		ERROR_MESS:= 'Failed to initialise PRNG - password must not contain international characters'

	else if (PRNG_ERROR = PRNG_ERROR_PASSWORD_LEN) then
		ERROR_MESS:= 'Failed to initialise PRNG - password length must be > zero and < 78'

	else ERROR_MESS:= 'Failed to initialise PRNG - unknown error';

	ERROR_CODE:= T_ERR_PRNG;
	exit;
	end;

// write data to output file

num_read:= -1;
repeat
	{$I-}
	blockread(INPUT_FILE,FILE_BYTES,BUFFER_SIZE,num_read);
	{$I+}
	if	(IOResult > 0) then
		begin
		ERROR_CODE:= T_ERR_COMPRESS;
		ERROR_MESS:= 'Input file read error ' + inttostr(IOResult);
		exit;
		end;
	if	(num_read > 0) then
		begin
        BLOCK_INDEX:= 0;
		while (BLOCK_INDEX < num_read) do
			begin
			Inc(BLOCK_INDEX);
			INPUT_BYTE:= FILE_BYTES[BLOCK_INDEX];
			OUTPUT_BYTE:= (INPUT_BYTE xor calc_8bit_rand(PRNG1));
	        FILE_BYTES[BLOCK_INDEX]:= OUTPUT_BYTE;
			end;
		{$I-}
		blockwrite(OUTPUT_FILE,FILE_BYTES,num_read,num_written);
		{$I+}
		if	(num_written < num_read)
		or	(IOResult > 0) then
			begin
			ERROR_CODE:= T_ERR_FILE;
			ERROR_MESS:= 'Output file write error ' + inttostr(IOResult);
			exit;
			end;
		end;
until	(num_read < BUFFER_SIZE);
end;


(*------------------------------*)
begin
PASSWORD_STR:= '';
OUTPUT_FILE_NAME:= '';
INPUT_FILE_NAME:= '';
SELECTED_FILE_NAME:= '';
PLAIN_FILE_NAME:= '';
BASE_FILE_NAME:= '';
CRYPT_FILE_NAME:= '';
FILE_CRYPT_TYPE	:= T_NULL_CRYPT;
COMPRESS_SETTING:= TRUE;
end.

