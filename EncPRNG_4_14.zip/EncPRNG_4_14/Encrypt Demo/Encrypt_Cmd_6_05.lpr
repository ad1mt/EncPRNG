{$MODE OBJFPC}
{$MODESWITCH NESTEDCOMMENTS+}

program Encrypt_Cmd_6_05;
uses	sysutils
,		strutils
,		strings
,		math
,		Encrypt_P
;

var
ENCRYPT_DECRYPT	:string;

(*------------------------------*)
begin

if (ParamCount < 4)
then
	begin
	writeln('Encrypt [z]encrypt|[z]decrypt <password>  <input_file>  <output_file>');
	exit;
	end;

ENCRYPT_DECRYPT:= ParamStr(1);
PASSWORD_STR:= ParamStr(2);
INPUT_FILE_NAME:= ParamStr(3);
OUTPUT_FILE_NAME:= ParamStr(4);

open_input_file;
if	(ERROR_CODE <> T_ERR_OK) then
	begin
    writeln(ERROR_MESS);
	exit;
	end;

open_output_file;
if	(ERROR_CODE <> T_ERR_OK) then
	begin
    writeln(ERROR_MESS);
	exit;
	end;

case ENCRYPT_DECRYPT of
	'encrypt':	encrypt_file;
	'decrypt':	decrypt_file;
	'zencrypt':	Compress_Encrypt;
	'zdecrypt':	Compress_Decrypt;
else
	begin
	ERROR_CODE:= T_ERR_PASSWORD;
	ERROR_MESS:= 'Invalid operation! Must be [z]encrypt|[z]decrypt';
	end
end;

if	(ERROR_CODE <> T_ERR_OK) then
	begin
    writeln(ERROR_MESS);
	exit;
	end;

close_output_file;
if	(ERROR_CODE <> T_ERR_OK) then
	begin
    writeln(ERROR_MESS);
	exit;
	end;

close_input_file;
end.

