@echo off
SET THEFILE=D:\Mark\Dev\Encrypt_P\Encrypt_P_1_10\Encrypt_Cmd_1_10B.exe
echo Linking %THEFILE%
D:\Programs\lazarus64\fpc\3.2.0\bin\x86_64-win64\ld.exe -b pei-x86-64  --gc-sections    --entry=_mainCRTStartup    -o D:\Mark\Dev\Encrypt_P\Encrypt_P_1_10\Encrypt_Cmd_1_10B.exe D:\Mark\Dev\Encrypt_P\Encrypt_P_1_10\link.res
if errorlevel 1 goto linkend
goto end
:asmend
echo An error occurred while assembling %THEFILE%
goto end
:linkend
echo An error occurred while linking %THEFILE%
:end
