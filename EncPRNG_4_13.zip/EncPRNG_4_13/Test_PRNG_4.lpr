{$MODE OBJFPC}
{$MODESWITCH NESTEDCOMMENTS+}

{
=======================================================================
 This program is intended for use in testing
 with a random testing program like Practrand
=======================================================================
}

program Test_PRNG_4;
uses	sysutils
,		strutils
,		strings
,		Unit_PRNG
;

var
I,R,E		:int_type;
COUNT		:int_type;
COUNT_STR	:string;
B			:int8u;
date_time	:int_type = 0;

PRNG2	:T_PRNG_record_RD;  // this type has infinite period when
							// initialised with the "ENABLE_INFINITE_PERIOD" option

PRNG1	:T_PRNG_record;		// this type does not have infinite period

(*------------------------------*)
begin
COUNT:= strtoint64def(ParamStr(1),0);

PRNG_initialise(PRNG1);							// initialise seeds the PRNG with
PRNG_initialise(PRNG2,ENABLE_INFINITE_PERIOD);	// a set of fixed variables
												// for predictable output

PRNG_randomise(PRNG1,E);	// the ramdonise function re-seeds the PRNG with random parameters
if	(E <> PRNG_ERROR_OK) then
	begin
	writeln('PRNG ERROR ',E);
	exit;
	end;

I:= 0;
repeat
	B:= calc_8bit_rand(PRNG1);
	write(chr(b));
	Inc(I);
until (I >= COUNT);
exit;

end.

