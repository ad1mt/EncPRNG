{$MODE OBJFPC}
{$MODESWITCH NESTEDCOMMENTS+}

program Demo_PRNG_4;
uses	sysutils
,		strutils
,		strings
,		Unit_PRNG
;

const
COUNT	= 5;

var
I,R			:int_type;
date_time	:int_type = 0;
prng_error	:int_type;

PRNG2	:T_PRNG_record_RD;  // this type has infinite period when
							// initialised with the "ENABLE_RECALC_SEEDS" option

PRNG1	:T_PRNG_record;		// this type does not have infinite period


(*------------------------------*)
begin

PRNG_initialise(PRNG1);
PRNG_initialise(PRNG2,ENABLE_INFINITE_PERIOD);

I:= 0;
repeat
	writeln(calc_24bit_rand(PRNG1),'	',calc_24bit_rand(PRNG2));
	Inc(I);
until (I >= COUNT);
writeln;

PRNG_randomise(PRNG1,prng_error);
if not PRNG1.INITIALISED then
	begin
	writeln('Failed to initialise PRNG1. PRNG_error=',prng_error);
	halt;
	end;

PRNG_randomise(PRNG2,prng_error);
if not PRNG2.INITIALISED then
	begin
	writeln('Failed to initialise PRNG2. PRNG_error=',prng_error);
	halt;
	end;

I:= 0;
repeat
	writeln(calc_16bit_rand(PRNG1),'	',calc_16bit_rand(PRNG2));
	Inc(I);
until (I >= COUNT);
writeln;

I:= 0;
repeat
	writeln(calc_32bit_rand(PRNG1),'	',calc_32bit_rand(PRNG2));
	Inc(I);
until (I >= COUNT);
writeln;

I:= 0;
repeat
	writeln(calc_64bit_rand(PRNG1),'	',calc_64bit_rand(PRNG2));
	Inc(I);
until (I >= COUNT);
writeln;

I:= 0;
repeat
	writeln(calc_single_float_rand(PRNG1),'	',calc_single_float_rand(PRNG2));
	Inc(I);
until (I >= COUNT);
writeln;

PRNG_randomise_from_password(PRNG1,' !#$%&()*+-/',date_time,prng_error);
if not PRNG1.INITIALISED then
	begin
	writeln('Failed to initialise PRNG1. PRNG_error=',prng_error);
	halt;
	end;

{ Infinite period not recommended for encryption }
PRNG_initialise(PRNG2);
PRNG_randomise_from_password(PRNG2,' !#$%&()*+-/',date_time,prng_error);
if not PRNG2.INITIALISED then
	begin
	writeln('Failed to initialise PRNG2. PRNG_error=',prng_error);
	halt;
	end;

I:= 0;
repeat
	r:= calc_8bit_rand(PRNG1);
	write(r,'	');
	r:= calc_8bit_rand(PRNG2);
	writeln(r);
	Inc(I);
until (I >= COUNT);
writeln;

end.

